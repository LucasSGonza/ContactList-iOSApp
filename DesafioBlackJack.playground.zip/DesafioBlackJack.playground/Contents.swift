import UIKit

/*Infos

- players + dealer(desk)
- cards from 2-10
- cards J,Q and K = 10
- card A = 1 OR 11 (it depends from what is better for the player)
- each player receive 2 cards, adding up the value of your cards

if sum > 21 -> lost // sum < 21 -> continue and receive one more card OR stop // sum == 21 -> win


Player -> receber cartas, pedir carta e parar
Dealer -> dar cartas para os players, dar carta para mesa(si mesmo)

*/
//------------------------------------------------------------

//code


enum Cards:Int, CaseIterable {
    
    case ás
    case two
    case three
    case four
    case five
    case six
    case seven
    case eight
    case nine
    case ten
    case J
    case Q
    case K
    
    var valueCards:Int {
        switch self {
        
        case .ás:
            return 1
        case .two:
            return 2
        case .three:
            return 3
        case.four:
            return 4
        case .five:
            return 5
        case .six:
            return 6
        case .seven:
            return 7
        case .eight:
            return 8
        case .nine:
            return 9
        case .ten, .J, .K, .Q:
            return 10
        }
    
    }
}


struct Players {
    //atributes/properties
    var cards: [Int] = [] //array to receive and store the cards
    var sumCards: Int = 0
    
    //methods/functions
    
    mutating func receiveCard(_ dealer:Dealer) -> Void {
        print("Receiving cards...")
        self.cards.append(dealer.givePlayerCard())
    }
 
}


struct Dealer {
    
    var deskCards: [Int] = [] //array to receive and store the cards
    //var deskCards: [Cards] = []
    var sumCards: Int = 0
    //var card = Cards()
    
    
    func givePlayerCard() -> Int {
        return (Int.random(in: 1...10))
    }
    
    mutating func giveDeskCard() -> Void {
        print("Delivering cards to the desk...")
        self.deskCards.append(Int.random(in: 1...10))
    }
    
    func sumValueCards(_ card:Int) -> Void{
        //self.sumCards = sumCards + card
    }
    
}


// Testing the game!

var player1 = Players()
var dealer = Dealer()

//repeat {

    print("Player cards: \(player1.cards)")
    print("Desk cards: \(dealer.deskCards)")

    player1.receiveCard(dealer)

    print("Delivering cards to the players...")
    dealer.givePlayerCard()

    dealer.giveDeskCard()

    print("Player cards: \(player1.cards)")
    print("Desk cards: \(dealer.deskCards)")

    //print(dealer.cards)
//} while (player1.sumCards <= 21 && dealer.sumCards <= 21)
