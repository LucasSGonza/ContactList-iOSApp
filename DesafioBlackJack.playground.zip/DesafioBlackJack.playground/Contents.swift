import UIKit

//2 players + dealer
//cards from 2-10
//cards J,Q and K = 10
//card A = 1 OR 11 (it depends from what is better for the player)
//each player receive 2 cards, adding up the value of your cards
//if sum > 21 -> lost // sum < 21 -> continue and receive one more card OR stop // sum == 21 -> win

struct Players {
    //atributes/properties
    var function:String
    
    //methods
    init(_ funcao:String) {
        function.self = funcao
    }
    
}

//da pra tirar esse init, mas sla tbm kkkkk
//let player1 = Players(  //visualizar a diferença entre usar _ e nao usar no init
