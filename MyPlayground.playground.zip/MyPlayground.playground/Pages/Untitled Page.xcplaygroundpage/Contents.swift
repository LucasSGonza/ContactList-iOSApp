import UIKit

/*
 //Testando simples Strings/Prints
 
 var str = "Hello, playground";
 print(str);
 
 var message = "Ola, ";
 message += "Lucas";
 print(message);
 */


/*
//Testando declarações, numeros, contas,...
let num1:Double = 7,
    num2:Double = 8,
    num3:Double = 9;
let mediaAluno: Double = (num1 + num2 + num3)/3;
let mediaEscola: Double = 6;

//print("Média aluno: ", mediaAluno);
print("Média aluno: \(mediaAluno)\nMédia escola: \(mediaEscola)");

/*
 let a = String(mediaAluno);
 print("Média: " + a);
 */

mediaAluno >= mediaEscola ? print("Aluno aprovado!") : print("Aluno reprovado!");
*/


/*
 //Testando condições
 let isHungry: Bool = false;
 
 if (isHungry == true){
 print("Vá comer");
 } else {
 print("Faça nada")
 }
 
 let product: String;
 let company: String = "Apple";
 
 /*
 if company == "Google" {
 product = "Android";
 } else {
 product = "iPhone";
 }
 */
 
 product = ((company == "Google") ? "Android" : "iPhone");
 product == "iPhone" ? print("tem iPhone") : print("tem Android");
 
 print("Empresa: ",company, "\nProduto: ", product);
 */


/*
 TUPLA
 
//tupla que possui as caracteristicas do gravador (DVR ou NVR, tipo, modelo)
let gravador = (dvr_nvr:"DVR",tipo:"MHDX",modelo:"MHDX 1332");
//print(gravador);
print("Gravador: \(gravador.0)\nTipo: \(gravador.tipo)\nModelo: \(gravador.modelo)");
*/


/*
 //ARRAY
 
var classA: [String] = ["Lucas", "Leticia","Silva","Kleber"];
print(classA)

classA.remove(at: 3);
print(classA)

classA.append("Carlos")
print(classA)

let newStudents = ["Felipe","Daniel"];
classA.append(contentsOf: newStudents);
//classA += newStudents;

print(classA)
 */
