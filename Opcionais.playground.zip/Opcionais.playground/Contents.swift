import UIKit

func calcMedia(_ num1:Double?, _ num2:Double?) -> Double {
    let media = ( (num1 ?? 0) + (num2 ?? 0) ) / 2
    return (media)
}

func calcMedia2(_ num1:Double?, _ num2:Double?) -> Double {
    var media: Double = 0.1
    if (num1 != nil && num2 != nil) { //simula um if let?
        media = (num1! + num2!) / 2
    }
    return media
}

func calcMedia3(_ num1:Double?, _ num2:Double?) -> Double {
    var media: Double = 0.2
    if let number1 = num1 {
        if let number2 = num2 {
            media = (number1 + number2) / 2
        }
    } else {
        media = 0.3
    }
    return media
}

func calcMedia4(_ num1:Double?, _ num2:Double?) -> Double {
    var media: Double = 0.1
    if let number1 = num1 {
        if let number2 = num2 {
            media = (number1 + number2) / 2
        }
    } else {
        let number1 = num1 ?? 0
        let number2 = num2 ?? 0
        media = (number1 + number2) / 2
    }
    return media
}


print(calcMedia(nil, 8))
print(calcMedia2(nil, 7))
print(calcMedia3(nil, 10))
print(calcMedia4(nil, 10))

