import UIKit

//Desafio consiste em criar um 'Jogo da Velha'

// Criar as linhas e colunas do jogo
var firstLine: (String,String,String) = ("","","")
var secondLine: (String,String,String) = ("","","")
var thirdLine: (String,String,String) = ("","","")
print("\(firstLine)\n\(secondLine)\n\(thirdLine)")

print("primeira linha = a\nsegunda linha = b\nterceira linha = c\n------\ncolunas = 1,2,3")

//Indicar os jogadores
let jogador1 = "o", jogador2 = "x"
print("Jogador 1 = o\nJogador 2 = x")


//queria utilizar entradas do usuário utilizando o comando readLine() mas pelo oq eu pesquisei esse comando não funciona no playground
/*
print("Jogador 1 deseja jogar em qual posição? (ex: a1 -> primeira linha, primeira coluna)");


if jogada == "a1" {
    firstLine.0 = jogador1;
}
*/

// Montando o jogo de forma manual
print("\nVamos começar!\nJogador 1 começa!")

secondLine.1 = jogador1
print("\n\(firstLine)\n\(secondLine)\n\(thirdLine)")

firstLine.0 = jogador2
print("\n\(firstLine)\n\(secondLine)\n\(thirdLine)")

thirdLine.0 = jogador1
print("\n\(firstLine)\n\(secondLine)\n\(thirdLine)")

secondLine.0 = jogador2
print("\n\(firstLine)\n\(secondLine)\n\(thirdLine)")

firstLine.2 = jogador1
print("\n\(firstLine)\n\(secondLine)\n\(thirdLine)")


//Verificar quem ganhou

//pensamento 1 => esqueci kk

//pensamento 2 => oq mais importa é verificar se houve uma sequencia de 3 caracteres, depois verificar quem fez essa sequencia (x ou o)
if firstLine.0 == "x" {
    if firstLine.1.isEmpty {
        print("a")
    } else {
        print("b")
    }
}

